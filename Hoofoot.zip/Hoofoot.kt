package com.hoofoot

import com.lagradost.cloudstream3.*
import com.lagradost.cloudstream3.MainAPI
import com.lagradost.cloudstream3.utils.*

class HoofootPlugin : MainAPI() {
    override var mainUrl = "https://hoofoot.com"
    override var name = "Hoofoot"
    override val hasMainPage = true

    override fun getMainPage(): HomePageResponse {
        val doc = app.get(mainUrl).document
        val videos = doc.select("td > a[href^=?match=]").map {
            val title = it.text()
            val href = fixUrl(it.attr("href"))
            newMovieSearchResponse(title, href, TvType.Movie) {
                this.posterUrl = null
            }
        }
        return newHomePageResponse("Highlights", videos)
    }

    override fun load(url: String): LoadResponse {
        val doc = app.get(url).document
        val title = doc.title()
        val iframe = doc.select("iframe").firstOrNull()?.attr("src") ?: return LoadResponse.ErrorLoading

        val video = Video(iframe, "Hoofoot Video", iframe)

        return newMovieLoadResponse(title, url, TvType.Movie, listOf(video))
    }
}