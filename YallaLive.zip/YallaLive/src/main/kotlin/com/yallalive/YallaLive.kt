package com.yallalive

import com.lagradost.cloudstream3.MainAPI
import com.lagradost.cloudstream3.TvType

class YallaLivePlugin: MainAPI() {
    override var mainUrl = "https://yallalive.sx"
    override var name = "YallaLive"
    override val hasMainPage = true
    override val supportedTypes = setOf(TvType.Live)
}