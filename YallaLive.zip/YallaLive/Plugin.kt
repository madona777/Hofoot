// use this file to declare metadata like plugin name, version & author

version = 1