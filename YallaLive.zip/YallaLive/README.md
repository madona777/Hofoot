# YallaLive Cloudstream Plugin

Plugin Cloudstream untuk streaming langsung dari [yallalive.sx](https://yallalive.sx).

**Fitur:**
- Tampilkan jadwal pertandingan olahraga
- Akses siaran langsung dari berbagai channel olahraga

**Catatan:** Plugin ini hanya sebagai pembuka halaman live streaming, tidak menyematkan stream langsung.